package cn.yunzhisheng.prodemo;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import cn.yunzhisheng.basic.USCRecognizerDialog;
import cn.yunzhisheng.basic.USCRecognizerDialogListener;
import cn.yunzhisheng.common.USCError;

/**
 * 云知声语音识别实例程序
 * @author user
 *
 */
public class AsrWeixinStyleActivity extends Activity  implements  OnClickListener {

	private TextView  mResultTextView;
	private USCRecognizerDialog mRecognizer;
	private Button  mDomainButton;
	private Button  mSampleButton;
	private Dialog   mDomainDialog;
	private Dialog   mSampleDialog;
	private Dialog mfunctionDialog;
	
	private int AsrType = ASR_ONLINE_TYPE;
	public static final int ASR_ONLINE_TYPE = 0;
	public static final int ASR_ONLINE_WEIXIN_TYPE = 2;
	
	private static  String  arraySampleStr[] = new String[]{"RATE_AUTO  ", "RATE_16K  ", "RATE_8K  "};
	private static  String  arrayDomain[] = new String[]{"general","poi","song","movietv","medical"};
	private static  String  arrayDomainChina[] = new  String[] {"通用识别  ","地名识别  ","歌名识别  ","影视名识别  ","医药领域识别  "};
	private static  int  arraySample[] = new int[]{USCRecognizerDialog.BANDWIDTH_AUTO, USCRecognizerDialog.RATE_16K,USCRecognizerDialog.RATE_8K};	
	private static  int  currentSample = 0;
	private static  int  currentDomain = 0;
	private static  int  currentLanguage = 0;
	
	private  Button  mRecognizerBtn;
	private ImageView mFunctionImageView;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_weixin);
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,
				R.layout.status_bar_main);
        
        initView();
		
		mRecognizerBtn = (Button) findViewById(R.id.recognizer_btn);
		mRecognizerBtn.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if(event.getAction()==MotionEvent.ACTION_DOWN){
					startRecognizer();
				}else if(event.getAction()==MotionEvent.ACTION_UP){
					stopRecognizer();
				}
				return false;
			}

		});
		
		//  创建识别对话框，appKey通过 http://dev.hivoice.cn/ 网站申请
		mRecognizer = new USCRecognizerDialog(this, Config.appKey);
			
		//  识别结果回调监听器.
		mRecognizer.setListener(new USCRecognizerDialogListener() {
			
			// 识别结果回调接口
			public void onResult(String result, boolean isLast) {
				//  通常onResult接口多次返回结果，保留识别结果组成完整的识别内容。
				mResultTextView.append(result);
			}
			
			//  识别结束回调接口.
			public void onEnd(USCError error) {
				// error为null表示识别成功，识别框自动关闭，可在此处理text结果，
				// error不为null，表示发生错误，对话框停留在错误页面
				if(error == null){
					
				}				
			}
		});
		
    }

	private void initView() {
		mResultTextView = (TextView) findViewById(R.id.result_textview);
    	mDomainButton = (Button) findViewById(R.id.domain_button);
		mSampleButton = (Button) findViewById(R.id.sample_button);
		mFunctionImageView = (ImageView) findViewById(R.id.function_button);
        mFunctionImageView.setOnClickListener(this);
		mDomainButton.setOnClickListener(this);
		mSampleButton.setOnClickListener(this);
		mDomainButton.setText(arrayDomainChina[0]);
		mSampleButton.setText(arraySampleStr[0]);
		// 功能选择
		mfunctionDialog = new Dialog(this, R.style.dialog);
		mfunctionDialog.setContentView(R.layout.function_list_item);
		mfunctionDialog.findViewById(R.id.asr_online_text).setOnClickListener(this);
		mfunctionDialog.findViewById(R.id.asr_online_weixin_text).setOnClickListener(this);
		// 识别领域
		mDomainDialog = new Dialog(this, R.style.dialog);
		mDomainDialog.setContentView(R.layout.domain_list_item);
		mDomainDialog.findViewById(R.id.medical_text).setOnClickListener(this);
		mDomainDialog.findViewById(R.id.general_text).setOnClickListener(this);
		mDomainDialog.findViewById(R.id.movietv_text).setOnClickListener(this);
		mDomainDialog.findViewById(R.id.poi_text).setOnClickListener(this);
		mDomainDialog.findViewById(R.id.song_text).setOnClickListener(this);
		// 采样率
		mSampleDialog = new Dialog(this, R.style.dialog);
		mSampleDialog.setContentView(R.layout.sample_list_item);
		mSampleDialog.findViewById(R.id.rate_16k_text).setOnClickListener(this);
		mSampleDialog.findViewById(R.id.rate_8k_text).setOnClickListener(this);
		mSampleDialog.findViewById(R.id.rate_auto_text).setOnClickListener(this);
	}
    
    /**
     * 关闭识别对话框
     */
	private void stopRecognizer() {
		mRecognizerBtn.setBackgroundColor(getResources().getColor(R.color.white));
		mRecognizerBtn.setText("按住  说话");
		if (mRecognizer != null) {
			mRecognizer.stop();
		}
	}
    
	/**
	 * 启动识别对话框
	 */
	private void startRecognizer() {
		mRecognizerBtn.setBackgroundColor(getResources().getColor(R.color.gray));
		mRecognizerBtn.setText("松开  结束");
		if (mRecognizer != null) {
			mRecognizer.show(false);
		}
	}
	

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		
		case R.id.domain_button:
			mDomainDialog.show();
			break;
			
		case  R.id.sample_button:
			mSampleDialog.show();
			break;	
			
		case R.id.general_text:
			currentDomain = 0;
			setDomain(currentDomain);
			break;

		case R.id.poi_text:
			currentDomain = 1;
			setDomain(currentDomain);
			break;

		case R.id.song_text:
			currentDomain = 2;
			setDomain(currentDomain);
			break;

		case R.id.movietv_text:
			currentDomain = 3;
			setDomain(currentDomain);
			break;

		case R.id.medical_text:
			currentDomain = 4;
			setDomain(currentDomain);
			break;		
		
		case R.id.rate_auto_text:
			currentSample = 0;
			setSample(currentSample);
			break;

		case R.id.rate_16k_text:
			currentSample = 1;
			setSample(currentSample);
			break;

		case R.id.rate_8k_text:
			currentSample = 2;
			setSample(currentSample);
			break;	
			
		case R.id.function_button:
			mfunctionDialog.show();
			break;

		case R.id.asr_online_text:
			AsrType = ASR_ONLINE_TYPE;
			changeView();
			break;
			
		case R.id.asr_online_weixin_text:
			AsrType = ASR_ONLINE_WEIXIN_TYPE;
			changeView();
			break;
			
		default:
			break;
		}
		
	}
	
	private void setSample(int index) {
		mSampleButton.setText(arraySampleStr[index]);
		mSampleDialog.dismiss();
	}

	private void setDomain(int index) {
		mDomainButton.setText(arrayDomainChina[index]);
		mDomainDialog.dismiss();
	}
	
	private void changeView() {
		if (AsrType == ASR_ONLINE_TYPE) {
			Intent intent = new Intent(this, MainActivity.class);
			this.startActivity(intent);
			this.finish();
		} else if (AsrType == ASR_ONLINE_WEIXIN_TYPE) {
			Intent intent = new Intent(this, AsrWeixinStyleActivity.class);
			this.startActivity(intent);
			this.finish();
		}
		mfunctionDialog.dismiss();
	}
}
