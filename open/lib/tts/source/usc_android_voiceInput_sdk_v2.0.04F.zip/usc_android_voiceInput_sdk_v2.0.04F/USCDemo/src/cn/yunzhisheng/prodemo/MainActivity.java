package cn.yunzhisheng.prodemo;

import java.util.List;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import cn.yunzhisheng.common.USCError;
import cn.yunzhisheng.pro.USCRecognizer;
import cn.yunzhisheng.pro.USCRecognizerListener;

/**
 * 云知声识别实例程序
 * 
 * @author
 * 
 */

public class MainActivity extends Activity implements OnClickListener {

	/**
	 * 当前识别状态
	 */
	enum AsrStatus {
		idle, recording, recognizing
	}

	private int AsrType = ASR_ONLINE_TYPE;
	public static final int ASR_ONLINE_TYPE = 0;
	public static final int ASR_ONLINE_WEIXIN_TYPE = 2;

	private ProgressBar mVolume;
	private EditText mResultTextView;
	private Button mRecognizerButton;
	private View mStatusView;
	private View mStatusLayout;
	private ImageView mLogoImageView;
	private TextView mStatusTextView;
	private Button mDomainButton;
	private Button mSampleButton;
	private ImageView mFunctionImageView;
	private Dialog mDomainDialog;
	private Dialog mSampleDialog;
	private Dialog mfunctionDialog;

	private static String arraySampleStr[] = new String[] { "RATE_AUTO  ",
			"RATE_16K  ", "RATE_8K  " };
	private static String arrayDomain[] = new String[] { "general", "poi",
			"song", "movietv", "medical" };
	private static String arrayDomainChina[] = new String[] { "通用识别  ",
			"地名识别  ", "歌名识别  ", "影视名识别  ", "医药领域识别  " };
	private static int arraySample[] = new int[] {
			USCRecognizer.BANDWIDTH_AUTO, USCRecognizer.RATE_16K,
			USCRecognizer.RATE_8K };
	private static int currentSample = 0;
	private static int currentDomain = 0;
	private static int currentLanguage = 0;

	private AsrStatus statue = AsrStatus.idle;
	private USCRecognizer mRecognizer;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_main);
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,
				R.layout.status_bar_main);

		initData();

		// 初始化识别对象
		initRecognizer();
	}

	/**
	 * 初始化识别
	 */
	private void initRecognizer() {

		// 创建识别对象，appKey通过 http://dev.hivoice.cn/ 网站申请
		mRecognizer = new USCRecognizer(this, Config.appKey);

		// 保存录音数据
		// recognizer.setRecordingDataEnable(true);
		mRecognizer.setListener(new USCRecognizerListener() {
			/**
			 * 识别结果实时返回
			 */
			@Override
			public void onResult(String result, boolean isLast) {

				// 通常onResult接口多次返回结果，保留识别结果组成完整的识别内容。
				mResultTextView.append(result);
			}

			/**
			 * 识别结束
			 */
			@Override
			public void onEnd(USCError error) {
				log_v("onEnd");

				mRecognizerButton.setEnabled(true);
				statue = AsrStatus.idle;
				mRecognizerButton.setText(R.string.click_say);
				mStatusLayout.setVisibility(View.GONE);
				mResultTextView.requestFocus();
				mResultTextView.setSelection(0);
				if (error != null) {
					// 显示错误信息
					mResultTextView.setText(error.toString());
				} else {
					if ("".equals(mResultTextView.getText().toString())) {
						mResultTextView.setText(R.string.no_hear_sound);
					}
				}
			}

			/**
			 * 检测用户停止说话回调
			 */
			@Override
			public void onVADTimeout() {
				log_v("onVADTimeout");

				// 收到用户停止说话事件，停止录音
				stopRecord();
			}

			/**
			 * 实时返回说话音量 0~100
			 */
			@Override
			public void onUpdateVolume(int volume) {
				mVolume.setProgress(volume);

			}

			/**
			 * 上传用户数据状态返回
			 */
			@Override
			public void onUploadUserData(USCError error) {
				log_v("onUploadUserData");

				if (error == null) {
					Toast.makeText(MainActivity.this,
							R.string.info_upload_success, Toast.LENGTH_LONG)
							.show();
				} else {
					Toast.makeText(MainActivity.this, error.toString(),
							Toast.LENGTH_LONG).show();
				}
			}

			/**
			 * 录音设备打开，开始识别，用户可以开始说话
			 */
			@Override
			public void onRecognizerStart() {
				log_v("onRecognizerStart");

				mStatusTextView.setText(R.string.please_speak);
				mRecognizerButton.setEnabled(true);
				statue = AsrStatus.recording;
				mRecognizerButton.setText(R.string.say_over);
			}

			/**
			 * 停止录音，请等待识别结果回调
			 */
			@Override
			public void onRecordingStop(List<byte[]> arg0) {
				log_v("onRecordingStop");

				statue = AsrStatus.recognizing;
				mRecognizerButton.setText(R.string.give_up);
				mStatusTextView.setText(R.string.just_recognizer);
			}

			/**
			 * 用户开始说话
			 */
			@Override
			public void onSpeechStart() {

				log_v("onSpeakStart");
				mStatusTextView.setText(R.string.speaking);
			}
		});
	}

	/**
	 * 初始化控件
	 */
	private void initData() {
		mVolume = (ProgressBar) findViewById(R.id.volume_progressbar);
		mResultTextView = (EditText) findViewById(R.id.result_textview);
		mResultTextView.setVisibility(View.INVISIBLE);
		mDomainButton = (Button) findViewById(R.id.domain_button);
		mSampleButton = (Button) findViewById(R.id.sample_button);
		mStatusView = findViewById(R.id.status_panel);
		mStatusTextView = (TextView) findViewById(R.id.status_show_textview);
		mStatusLayout = findViewById(R.id.status_layout);
		mLogoImageView = (ImageView) findViewById(R.id.logo_imageview);
		mFunctionImageView = (ImageView) findViewById(R.id.function_button);
        mFunctionImageView.setOnClickListener(this);
		mDomainButton.setOnClickListener(this);
		mSampleButton.setOnClickListener(this);
		mDomainButton.setText(arrayDomainChina[0]);
		mSampleButton.setText(arraySampleStr[0]);

		mRecognizerButton = (Button) findViewById(R.id.recognizer_btn);

		// 功能选择
		mfunctionDialog = new Dialog(this, R.style.dialog);
		mfunctionDialog.setContentView(R.layout.function_list_item);
		mfunctionDialog.findViewById(R.id.asr_online_text).setOnClickListener(
				this);
		mfunctionDialog.findViewById(R.id.asr_online_weixin_text)
				.setOnClickListener(this);

		// 识别领域
		mDomainDialog = new Dialog(this, R.style.dialog);
		mDomainDialog.setContentView(R.layout.domain_list_item);
		mDomainDialog.findViewById(R.id.medical_text).setOnClickListener(this);
		mDomainDialog.findViewById(R.id.general_text).setOnClickListener(this);
		mDomainDialog.findViewById(R.id.movietv_text).setOnClickListener(this);
		mDomainDialog.findViewById(R.id.poi_text).setOnClickListener(this);
		mDomainDialog.findViewById(R.id.song_text).setOnClickListener(this);
		// 采样率
		mSampleDialog = new Dialog(this, R.style.dialog);
		mSampleDialog.setContentView(R.layout.sample_list_item);
		mSampleDialog.findViewById(R.id.rate_16k_text).setOnClickListener(this);
		mSampleDialog.findViewById(R.id.rate_8k_text).setOnClickListener(this);
		mSampleDialog.findViewById(R.id.rate_auto_text)
				.setOnClickListener(this);

		mRecognizerButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (statue == AsrStatus.idle) {
					mResultTextView.setVisibility(View.VISIBLE);
					mRecognizerButton.setEnabled(false);
					mResultTextView.setText("");
					mStatusView.setVisibility(View.VISIBLE);
					mStatusLayout.setVisibility(View.VISIBLE);
					mLogoImageView.setVisibility(View.GONE);
					// 在收到 onRecognizerStart 回调前，录音设备没有打开，请添加界面等待提示，
					// 录音设备打开前用户说的话不能被识别到，影响识别效果。
					mStatusTextView.setText(R.string.opening_recode_devices);
					// 修改录音采样率
					mRecognizer.setBandwidth(arraySample[currentSample]);
					// 修改识别领域
					mRecognizer.setEngine(arrayDomain[currentDomain]);

					mRecognizer.start();
				} else if (statue == AsrStatus.recording) {
					stopRecord();
				} else if (statue == AsrStatus.recognizing) {

					mRecognizer.cancel();

					mRecognizerButton.setText(R.string.click_say);
					statue = AsrStatus.idle;
				}
			}
		});
	}

	/**
	 * 打印日志信息
	 * 
	 * @param msg
	 */
	private void log_v(String msg) {
		Log.v("demo", msg);
	}

	/**
	 * 停止录音
	 */
	public void stopRecord() {
		mStatusTextView.setText(R.string.just_recognizer);
		mRecognizer.stop();
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {

		case R.id.domain_button:
			mDomainDialog.show();
			break;

		case R.id.sample_button:
			mSampleDialog.show();
			break;

		case R.id.general_text:
			currentDomain = 0;
			setDomain(currentDomain);
			break;

		case R.id.poi_text:
			currentDomain = 1;
			setDomain(currentDomain);
			break;

		case R.id.song_text:
			currentDomain = 2;
			setDomain(currentDomain);
			break;

		case R.id.movietv_text:
			currentDomain = 3;
			setDomain(currentDomain);
			break;

		case R.id.medical_text:
			currentDomain = 4;
			setDomain(currentDomain);
			break;

		case R.id.rate_auto_text:
			currentSample = 0;
			setSample(currentSample);
			break;

		case R.id.rate_16k_text:
			currentSample = 1;
			setSample(currentSample);
			break;

		case R.id.rate_8k_text:
			currentSample = 2;
			setSample(currentSample);
			break;

		case R.id.function_button:
			mfunctionDialog.show();
			break;

		case R.id.asr_online_text:
			AsrType = ASR_ONLINE_TYPE;
			changeView();
			break;
			
		case R.id.asr_online_weixin_text:
			AsrType = ASR_ONLINE_WEIXIN_TYPE;
			changeView();
			break;

		default:
			break;
		}

	}
	
    @Override
	protected void onStop() {
		super.onStop();
		if (mRecognizer != null) {
			mRecognizer.stop();
		}
	}

	private void setSample(int index) {
		mSampleButton.setText(arraySampleStr[index]);
		mSampleDialog.dismiss();
	}

	private void setDomain(int index) {
		mDomainButton.setText(arrayDomainChina[index]);
		mDomainDialog.dismiss();
	}

	private void changeView() {
		if (AsrType == ASR_ONLINE_TYPE) {
			Intent intent = new Intent(this, MainActivity.class);
			this.startActivity(intent);
			this.finish();
		} else if (AsrType == ASR_ONLINE_WEIXIN_TYPE) {
			Intent intent = new Intent(this, AsrWeixinStyleActivity.class);
			this.startActivity(intent);
			this.finish();
		}
		mfunctionDialog.dismiss();
	}

}
