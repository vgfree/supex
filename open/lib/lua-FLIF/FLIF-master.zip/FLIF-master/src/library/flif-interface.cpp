#include "flif-interface_dec.cpp"
#include "flif-interface_enc.cpp"

