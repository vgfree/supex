/////////////////////////////////////////////////////////////////////////////
// Name:        class_smartpointers.h
// Purpose:     Smart Pointer classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_smartpointers Smart Pointers
@ingroup group_class

wxWidgets provides a few smart pointer class templates.

*/

