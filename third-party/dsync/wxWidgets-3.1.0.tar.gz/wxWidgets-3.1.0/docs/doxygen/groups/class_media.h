/////////////////////////////////////////////////////////////////////////////
// Name:        class_media.h
// Purpose:     Multimedia classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_media Multimedia
@ingroup group_class

Classes for showing multimedia contents.

*/

