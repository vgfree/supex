#ifndef VERSION_HEADER_434343489702544325
#define VERSION_HEADER_434343489702544325

namespace zen
{
const wchar_t ffsVersion[] = L"8.5"; //internal linkage!
const wchar_t FFS_VERSION_SEPARATOR = L'.';
}

#endif
