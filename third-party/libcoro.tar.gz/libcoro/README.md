libcoro
=======

Original sources from CVS libcoro (http://software.schmorp.de/pkg/libcoro.html).

Original README
---------------

Configuration, documentation etc. is provided in the coro.h file.  Please
note that the file conftest.c in this distribution is under the GPL. It is
not needed for proper operation of this library though, for that, coro.h
and coro.c suffice.
