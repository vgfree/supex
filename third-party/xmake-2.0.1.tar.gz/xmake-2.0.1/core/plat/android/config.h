#ifndef XM_CONFIG_H
#define XM_CONFIG_H

// packages
// [packages]

// major version
#define XM_CONFIG_VERSION_MAJOR         [major]

// minor version
#define XM_CONFIG_VERSION_MINOR         [minor]

// alter version
#define XM_CONFIG_VERSION_ALTER         [alter]

// build version
#define XM_CONFIG_VERSION_BUILD         [build]

// small
#define XM_CONFIG_SMALL                 [small]

#endif
