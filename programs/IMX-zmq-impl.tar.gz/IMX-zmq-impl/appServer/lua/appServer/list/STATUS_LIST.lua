module("STATUS_LIST")


OWN_LIST = {
	{"upstream", "open"},
	{"status", "open"},
}
