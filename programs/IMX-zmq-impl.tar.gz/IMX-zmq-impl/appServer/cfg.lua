module("cfg")

DEFAULT_LOG_PATH = "./logs"
LOGLV = 1
