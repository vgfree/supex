#pragma once

void control_gateway_work(void);

void control_gateway_wait(void);

void control_gateway_stop(void);

