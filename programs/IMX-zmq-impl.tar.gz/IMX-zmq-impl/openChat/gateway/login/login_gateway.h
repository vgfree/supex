#pragma once

void login_gateway_work(void);

void login_gateway_wait(void);

void login_gateway_stop(void);

