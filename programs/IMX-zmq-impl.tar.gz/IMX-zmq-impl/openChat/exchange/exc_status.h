#pragma once

int erase_client(int fd);

void send_status_msg(int clientfd, int status);

