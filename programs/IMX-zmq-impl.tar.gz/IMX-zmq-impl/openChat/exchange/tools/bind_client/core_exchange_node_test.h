#ifndef _CORE_EXCHANGE_NODE_TEST_H
#define _CORE_EXCHANGE_NODE_TEST_H

#include "router.h"

#include <stdlib.h>

int test_uid_map();

int test_gid_map();

int test_simulate_client(char *ip);

int test_simulate_gateway();

#endif

