#pragma once

void exchange_work(void);

void exchange_wait(void);

void exchange_stop(void);
