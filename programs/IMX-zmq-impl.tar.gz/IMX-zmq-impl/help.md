openChat:
	1.可用于即时通讯。
	2.可用于服务订阅。
	子模块:
	exchange	---> 核心交换
	controlGateway	---> 下行关系/状态
	loginGateway	---> 上行状态
	messageGateway	---> 上下行消息
