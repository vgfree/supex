module("link")

OWN_POOL = {
	lhttp = {},
	redis = {},
	mysql = {},
}

OWN_DIED = {
	mysql = {},
	http = {},
}
