module("link")

OWN_POOL = {
	redis = {
                IMX = {
                        host = '127.0.0.1',
                        port = 6379,
                },
        },
}

OWN_DIED = {
	mysql = {},
	http = {                                                              
        }
}
