#!/usr/bin/env python
import pylint
pylint.run_pylint()
