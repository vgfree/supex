var searchData=
[
  ['lasterror',['lastError',['../structzen_1_1_xml_file_error.html#a4a109e749675a3887af8cfc140303b8f',1,'zen::XmlFileError']]]
];
