var searchData=
[
  ['addchild',['addChild',['../classzen_1_1_xml_element.html#a653caffa6fad89db7d14f67f987ad0f9',1,'zen::XmlElement']]],
  ['attribute',['attribute',['../classzen_1_1_xml_out.html#acaf9b71fe1d907dd63dd4b91e2e03805',1,'zen::XmlOut::attribute()'],['../classzen_1_1_xml_in.html#a971cd7054c551c4460d5220f6ec5cf01',1,'zen::XmlIn::attribute()']]]
];
