var searchData=
[
  ['next',['next',['../classzen_1_1_xml_in.html#a60cf2678c989621545d27745dcafa4a4',1,'zen::XmlIn']]]
];
