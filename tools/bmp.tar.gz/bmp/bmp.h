#pragma once

typedef struct __attribute__((packed))
{
	unsigned short bfType;
	unsigned int   bfSize;
	unsigned short bfReserved1;
	unsigned short bfReserved2;
	unsigned int   bfOffBits;
} BMP_FILE_HEADER;

typedef struct __attribute__((packed))
{
	unsigned int   biSize;
	int            biWidth;
	int            biHeight;
	unsigned short biPlanes;
	unsigned short biBitCount;
	unsigned int   biCompression;
	unsigned int   biSizeImage;
	int            biXPelsPerMeter;
	int            biYPelsPerMeter;
	unsigned int   biClrUsed;
	unsigned int   biClrImportant;
} BMP_INFO_HEADER;

unsigned char *bmp_load(const char *name, BMP_FILE_HEADER *h_file, BMP_INFO_HEADER *h_info, unsigned int *size);

unsigned int bmp_init(BMP_FILE_HEADER *h_file, BMP_INFO_HEADER *h_info, unsigned int width, unsigned int height);

void bmp_save(const char *name, BMP_FILE_HEADER *h_file, BMP_INFO_HEADER *h_info, const char *buf, unsigned int size);

void bmp_draw(char *buf, unsigned int width, unsigned int height, unsigned int offset_x, unsigned int offset_y);

void bmp_square(char *buf, unsigned int width, unsigned int height, unsigned int offset_x, unsigned int offset_y, unsigned int radius);

void bmp_circle(char *buf, unsigned int width, unsigned int height, unsigned int offset_x, unsigned int offset_y, unsigned int radius);
