#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "bmp.h"

/*
 * 1. 定义bmp文件头，必须要加 __attribute__((packed))，意思是告诉编译器取消结构在编译过程中的优化对齐,按照实际占用字节数进行对齐，是GCC特有的语法。
 *    否则编译器自动对齐之后，BMP_FILE_HEADER本来应该是14字节，就变成了16字节，这样生成的bmp文件整个就乱了，就不能被当作一个图形文件来查看了。
 * 2. bmp文件内的像素数据，其宽度必须是4字节的倍数，也就是说下面代码中bmpinfo.biWidth必须是4的倍数。
 * 3. bmpinfo.biBitCount = 24; 我这里用的是rgb格式的数据，所以每个像素点是24bit。
 */

unsigned int bmp_init(BMP_FILE_HEADER *h_file, BMP_INFO_HEADER *h_info, unsigned int width, unsigned int height)
{
	h_file->bfType = 0x4D42;
	h_file->bfSize = sizeof(BMP_FILE_HEADER) + sizeof(BMP_INFO_HEADER) + (3 * (width * height));
	h_file->bfReserved1 = 0;
	h_file->bfReserved2 = 0;
	h_file->bfOffBits = sizeof(BMP_FILE_HEADER) + sizeof(BMP_INFO_HEADER);

	h_info->biSize = sizeof(BMP_INFO_HEADER);
	h_info->biWidth = width;
	h_info->biHeight = height;
	h_info->biPlanes = 1;
	h_info->biBitCount = 24; //RGB
	h_info->biCompression = 0;
	h_info->biSizeImage = width * height * 3;
	h_info->biXPelsPerMeter = 1;
	h_info->biYPelsPerMeter = 1;
	h_info->biClrUsed = 0;
	h_info->biClrImportant = 0;

	return (width* height * 3);
}
void bmp_save(const char *name, BMP_FILE_HEADER *h_file, BMP_INFO_HEADER *h_info, const char *buf, unsigned int size)
{
	FILE * outfile = fopen(name, "w+b");
	assert(outfile);

	fwrite(h_file, 1, sizeof(BMP_FILE_HEADER), outfile);
	fwrite(h_info, 1, sizeof(BMP_INFO_HEADER), outfile);
	fwrite(buf, 1, size, outfile);

	fclose(outfile);
	return;
}
unsigned char *bmp_load(const char *name, BMP_FILE_HEADER *h_file, BMP_INFO_HEADER *h_info, unsigned int *size)
{
	FILE * infile = fopen(name, "r");
	assert(infile);

	fread(h_file, 1, sizeof(BMP_FILE_HEADER), infile);
	fread(h_info, 1, sizeof(BMP_INFO_HEADER), infile);
	printf("BIT : %d\n", h_info->biBitCount);
	*size = (h_info->biWidth * h_info->biHeight) * (h_info->biBitCount / 8);
	char *buf = malloc(*size);
	assert(buf);
	fread(buf, 1, *size, infile);

	fclose(infile);
	return buf;
}

void bmp_draw(char *buf, unsigned int width, unsigned int height,
		unsigned int offset_x, unsigned int offset_y)
{
	if (offset_x > width){
		printf("\x1B[0;32m" "x is outside of bmp!\n" "\x1B[m");
		return;
	}
	if (offset_y > height){
		printf("\x1B[0;32m" "y is outside of bmp!\n" "\x1B[m");
		return;
	}
	buf[ (offset_y * width + offset_x) * 3 ] = 0;
	buf[ (offset_y * width + offset_x) * 3 + 1 ] = 254;
	buf[ (offset_y * width + offset_x) * 3 + 2 ] = 0;
	return;
}
void bmp_square(char *buf, unsigned int width, unsigned int height,
		unsigned int offset_x, unsigned int offset_y, unsigned int radius)
{
	if (radius > width || radius > height || radius < 0){
		printf("\x1B[0;32m" "radius is error!\n" "\x1B[m");
		return;
	}
	unsigned int min_x = (radius >= offset_x) ? 0 : offset_x - radius;
	unsigned int max_x = (radius + offset_x >= width) ? width : offset_x + radius;
	unsigned int min_y = (radius >= offset_y) ? 0 : offset_y - radius;
	unsigned int max_y = (radius + offset_y >= height) ? height : offset_y + radius;
	unsigned int x,y;
	for(x = min_x; x <= max_x; x ++ ){
		for(y = min_y; y <= max_y; y ++ ){
			bmp_draw(buf, width, height, x, y);
		}
	}
	return;
}

void bmp_circle(char *buf, unsigned int width, unsigned int height,
		unsigned int offset_x, unsigned int offset_y, unsigned int radius)
{
	if (radius > width || radius > height || radius < 0){
		printf("\x1B[0;32m" "radius is error!\n" "\x1B[m");
		return;
	}
	unsigned int min_x = (radius >= offset_x) ? 0 : offset_x - radius;
	unsigned int max_x = (radius + offset_x >= width) ? width : offset_x + radius;
	unsigned int min_y = (radius >= offset_y) ? 0 : offset_y - radius;
	unsigned int max_y = (radius + offset_y >= height) ? height : offset_y + radius;
	unsigned int x,y;
	unsigned int x1,y1;
	unsigned int x2,y2;
	for(x = min_x; x <= max_x; x ++ ){
		for(y = min_y; y <= max_y; y ++ ){
			x1 = (x <= offset_x) ? (offset_x - x) : (x - offset_x);
			x2 = x1 * x1; 
			y1 = (y <= offset_y) ? (offset_y - y) : (y - offset_y);
			y2 = y1 * y1; 
			double len = sqrt( x2 + y2 );
			if ( len <= radius ){
				bmp_draw(buf, width, height, x, y);
			}
		}
	}
	return;
}
